package com.smartcanteen.db;

import com.smartcanteen.model.CartItem;
import com.smartcanteen.model.FoodItem;
import com.smartcanteen.model.OrderSummary;
import com.smartcanteen.model.UserAccount;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class DatabaseService implements AutoCloseable {
    private final String url;
    private final String username;
    private final String password;
    private volatile boolean available;
    private volatile String lastError;

    public DatabaseService() {
        url = setting("db.url", "SMART_CANTEEN_DB_URL",
                "jdbc:mysql://localhost:3306/smart_canteen?createDatabaseIfNotExist=true&serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true");
        username = setting("db.user", "SMART_CANTEEN_DB_USER", "root");
        password = setting("db.password", "SMART_CANTEEN_DB_PASSWORD", "root");
    }

    private static String setting(String systemProperty, String environmentVariable, String defaultValue) {
        String value = System.getProperty(systemProperty);
        if (value == null || value.isBlank()) value = System.getenv(environmentVariable);
        return value == null || value.isBlank() ? defaultValue : value;
    }

    public void initialize() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC driver was not found.", e);
        }
        try (Connection connection = getConnection(); Statement statement = connection.createStatement()) {
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS users (
                        id INT PRIMARY KEY AUTO_INCREMENT,
                        username VARCHAR(50) NOT NULL UNIQUE,
                        password_hash CHAR(64) NOT NULL,
                        role VARCHAR(20) NOT NULL,
                        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        INDEX idx_users_role (role)
                    ) ENGINE=InnoDB""");
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS food_items (
                        id INT PRIMARY KEY AUTO_INCREMENT,
                        name VARCHAR(100) NOT NULL UNIQUE,
                        description VARCHAR(255) NOT NULL,
                        category VARCHAR(50) NOT NULL,
                        price DECIMAL(10,2) NOT NULL,
                        available BOOLEAN NOT NULL DEFAULT TRUE,
                        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                    ) ENGINE=InnoDB""");
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS orders (
                        id INT PRIMARY KEY AUTO_INCREMENT,
                        token_number VARCHAR(30) NOT NULL UNIQUE,
                        student_name VARCHAR(100) NOT NULL,
                        total_amount DECIMAL(10,2) NOT NULL,
                        status VARCHAR(20) NOT NULL DEFAULT 'PENDING',
                        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                        INDEX idx_orders_status (status),
                        INDEX idx_orders_created_at (created_at)
                    ) ENGINE=InnoDB""");
            statement.executeUpdate("""
                    CREATE TABLE IF NOT EXISTS order_details (
                        id INT PRIMARY KEY AUTO_INCREMENT,
                        order_id INT NOT NULL,
                        food_item_id INT NOT NULL,
                        quantity INT NOT NULL,
                        unit_price DECIMAL(10,2) NOT NULL,
                        CONSTRAINT fk_details_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
                        CONSTRAINT fk_details_food FOREIGN KEY (food_item_id) REFERENCES food_items(id),
                        CONSTRAINT chk_details_quantity CHECK (quantity > 0)
                    ) ENGINE=InnoDB""");
            // Migrate orders created by the earlier version, which used COMPLETED.
            statement.executeUpdate("UPDATE orders SET status = 'READY' WHERE status = 'COMPLETED'");
        }
        seedAdminAccount();
        seedFoodItems();
        available = true;
        lastError = null;
    }

    private void seedAdminAccount() throws SQLException {
        String sql = "INSERT IGNORE INTO users (username, password_hash, role) VALUES (?, ?, 'ADMIN')";
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, "admin");
            statement.setString(2, hashPassword("admin123"));
            statement.executeUpdate();
        }
    }

    public UserAccount authenticate(String username, String password, String role) throws SQLException {
        String cleanUsername = username == null ? "" : username.trim();
        if (cleanUsername.isBlank() || password == null || password.isBlank()) {
            throw new IllegalArgumentException("Enter both username and password.");
        }
        if (!List.of("STUDENT", "ADMIN").contains(role)) throw new IllegalArgumentException("Invalid login role.");
        String sql = "SELECT username, role FROM users WHERE username = ? AND password_hash = ? AND role = ?";
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, cleanUsername);
            statement.setString(2, hashPassword(password));
            statement.setString(3, role);
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) throw new IllegalArgumentException("Invalid username or password.");
                return new UserAccount(result.getString("username"), result.getString("role"));
            }
        }
    }

    public void registerStudent(String username, String password) throws SQLException {
        String cleanUsername = username == null ? "" : username.trim();
        if (!cleanUsername.matches("[A-Za-z][A-Za-z0-9_.-]{2,49}")) {
            throw new IllegalArgumentException("Username must start with a letter and contain 3–50 letters, numbers, dots, dashes, or underscores.");
        }
        if (password == null || password.length() < 6 || password.length() > 100) {
            throw new IllegalArgumentException("Password must be between 6 and 100 characters.");
        }
        String sql = "INSERT INTO users (username, password_hash, role) VALUES (?, ?, 'STUDENT')";
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, cleanUsername);
            statement.setString(2, hashPassword(password));
            statement.executeUpdate();
        } catch (SQLIntegrityConstraintViolationException exception) {
            throw new IllegalArgumentException("That username is already registered.", exception);
        }
    }

    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder result = new StringBuilder();
            for (byte value : bytes) result.append(String.format("%02x", value));
            return result.toString();
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("Password hashing is unavailable.", exception);
        }
    }

    private void seedFoodItems() throws SQLException {
        String sql = "INSERT INTO food_items (name, description, category, price, available) VALUES (?, ?, ?, ?, TRUE) " +
                "ON DUPLICATE KEY UPDATE description = ?, category = ?, price = ?, available = TRUE";
        Object[][] samples = {
                {"Veg Thali", "Rice, dal, two vegetables and chapati", "Meals", new BigDecimal("80.00")},
                {"Masala Dosa", "Crispy dosa with potato masala and chutney", "South Indian", new BigDecimal("55.00")},
                {"Paneer Wrap", "Soft wrap filled with spiced paneer and salad", "Snacks", new BigDecimal("65.00")},
                {"Lemon Juice", "Fresh lemon drink served chilled", "Beverages", new BigDecimal("25.00")},
                {"Idli Sambar", "Three steamed idlis with hot sambar", "South Indian", new BigDecimal("45.00")},
                {"Aloo Paratha", "Stuffed paratha served with curd and pickle", "North Indian", new BigDecimal("60.00")},
                {"Veg Fried Rice", "Wok-tossed rice with vegetables and spring onion", "Chinese", new BigDecimal("75.00")},
                {"Samosa", "Crispy pastry filled with spiced potato", "Snacks", new BigDecimal("20.00")},
                {"Fresh Lime Soda", "Refreshing lime soda with mint", "Beverages", new BigDecimal("35.00")},
                {"Chole Bhature", "Fluffy bhatura with spiced chickpeas", "North Indian", new BigDecimal("90.00")},
                {"Veg Burger", "Toasted bun with vegetable patty and fresh salad", "Fast Food", new BigDecimal("70.00")},
                {"Fruit Bowl", "Seasonal fresh fruit with a light honey drizzle", "Healthy", new BigDecimal("50.00")}
        };
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            for (Object[] item : samples) {
                statement.setString(1, (String) item[0]);
                statement.setString(2, (String) item[1]);
                statement.setString(3, (String) item[2]);
                statement.setBigDecimal(4, (BigDecimal) item[3]);
                statement.setString(5, (String) item[1]);
                statement.setString(6, (String) item[2]);
                statement.setBigDecimal(7, (BigDecimal) item[3]);
                statement.addBatch();
            }
            statement.executeBatch();
        }
    }

    public List<FoodItem> findAvailableFoodItems() throws SQLException {
        List<FoodItem> items = new ArrayList<>();
        String sql = "SELECT id, name, description, category, price FROM food_items WHERE available = TRUE ORDER BY category, name";
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet result = statement.executeQuery()) {
            while (result.next()) {
                items.add(new FoodItem(result.getInt("id"), result.getString("name"),
                        result.getString("description"), result.getString("category"), result.getBigDecimal("price"), true));
            }
            if (items.isEmpty()) return demoFoodItems();
            available = true;
            lastError = null;
            return items;
        } catch (SQLException exception) {
            available = false;
            lastError = friendlyDatabaseError(exception);
            return demoFoodItems();
        }
    }

    /** Returns the built-in menu used while MySQL is unavailable or has no rows yet. */
    public List<FoodItem> demoFoodItems() {
        return List.of(
                new FoodItem(-1, "Veg Thali", "Rice, dal, two vegetables and chapati", "Meals", new BigDecimal("80.00")),
                new FoodItem(-2, "Masala Dosa", "Crispy dosa with potato masala and chutney", "South Indian", new BigDecimal("55.00")),
                new FoodItem(-3, "Paneer Wrap", "Soft wrap filled with spiced paneer and salad", "Snacks", new BigDecimal("65.00")),
                new FoodItem(-4, "Lemon Juice", "Fresh lemon drink served chilled", "Beverages", new BigDecimal("25.00")),
                new FoodItem(-5, "Idli Sambar", "Three steamed idlis with hot sambar", "South Indian", new BigDecimal("45.00")),
                new FoodItem(-6, "Aloo Paratha", "Stuffed paratha served with curd and pickle", "North Indian", new BigDecimal("60.00")),
                new FoodItem(-7, "Veg Fried Rice", "Wok-tossed rice with vegetables and spring onion", "Chinese", new BigDecimal("75.00")),
                new FoodItem(-8, "Samosa", "Crispy pastry filled with spiced potato", "Snacks", new BigDecimal("20.00")),
                new FoodItem(-9, "Fresh Lime Soda", "Refreshing lime soda with mint", "Beverages", new BigDecimal("35.00")),
                new FoodItem(-10, "Chole Bhature", "Fluffy bhatura with spiced chickpeas", "North Indian", new BigDecimal("90.00")),
                new FoodItem(-11, "Veg Burger", "Toasted bun with vegetable patty and fresh salad", "Fast Food", new BigDecimal("70.00")),
                new FoodItem(-12, "Fruit Bowl", "Seasonal fresh fruit with a light honey drizzle", "Healthy", new BigDecimal("50.00"))
        );
    }

    public boolean isAvailable() { return available; }

    public String getLastError() { return lastError; }

    public String friendlyDatabaseError(SQLException exception) {
        String message = exception.getMessage();
        if (message == null || message.isBlank()) return "Unable to connect to MySQL.";
        if (message.contains("Communications link failure") || message.contains("Connection refused")
                || message.contains("Connection timed out")) {
            return "MySQL is not running or the connection settings are incorrect.";
        }
        if (message.contains("Access denied")) {
            return "MySQL rejected the username or password. Start the app with the correct -Ddb.user and -Ddb.password values.";
        }
        return message.length() > 180 ? message.substring(0, 180) + "…" : message;
    }

    public String placeOrder(String studentName, List<CartItem> cart) throws SQLException {
        if (studentName == null || studentName.trim().length() < 2 || studentName.trim().length() > 100) {
            throw new IllegalArgumentException("Enter a student name between 2 and 100 characters.");
        }
        if (cart == null || cart.isEmpty()) throw new IllegalArgumentException("Add at least one item to the cart.");

        try (Connection connection = getConnection()) {
            connection.setAutoCommit(false);
            try {
                BigDecimal total = BigDecimal.ZERO;
                List<BigDecimal> currentPrices = new ArrayList<>();
                String priceSql = "SELECT price FROM food_items WHERE id = ? AND available = TRUE";
                try (PreparedStatement priceStatement = connection.prepareStatement(priceSql)) {
                    for (CartItem cartItem : cart) {
                        if (cartItem.getQuantity() < 1 || cartItem.getQuantity() > 20) {
                            throw new IllegalArgumentException("Each item quantity must be between 1 and 20.");
                        }
                        priceStatement.setInt(1, cartItem.getFoodItem().getId());
                        try (ResultSet result = priceStatement.executeQuery()) {
                            if (!result.next()) throw new IllegalArgumentException("One selected item is no longer available.");
                            BigDecimal price = result.getBigDecimal("price");
                            currentPrices.add(price);
                            total = total.add(price.multiply(BigDecimal.valueOf(cartItem.getQuantity())));
                        }
                    }
                }

                String token = createToken();
                int orderId;
                String orderSql = "INSERT INTO orders (token_number, student_name, total_amount) VALUES (?, ?, ?)";
                try (PreparedStatement orderStatement = connection.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS)) {
                    orderStatement.setString(1, token);
                    orderStatement.setString(2, studentName.trim());
                    orderStatement.setBigDecimal(3, total);
                    orderStatement.executeUpdate();
                    try (ResultSet keys = orderStatement.getGeneratedKeys()) {
                        if (!keys.next()) throw new SQLException("The database did not return the new order ID.");
                        orderId = keys.getInt(1);
                    }
                }

                String detailSql = "INSERT INTO order_details (order_id, food_item_id, quantity, unit_price) VALUES (?, ?, ?, ?)";
                try (PreparedStatement detailStatement = connection.prepareStatement(detailSql)) {
                    for (int i = 0; i < cart.size(); i++) {
                        CartItem cartItem = cart.get(i);
                        detailStatement.setInt(1, orderId);
                        detailStatement.setInt(2, cartItem.getFoodItem().getId());
                        detailStatement.setInt(3, cartItem.getQuantity());
                        detailStatement.setBigDecimal(4, currentPrices.get(i));
                        detailStatement.addBatch();
                    }
                    detailStatement.executeBatch();
                }
                connection.commit();
                return token;
            } catch (Exception exception) {
                connection.rollback();
                if (exception instanceof SQLException sqlException) throw sqlException;
                if (exception instanceof IllegalArgumentException argumentException) throw argumentException;
                throw new SQLException("Could not place the order.", exception);
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    private String createToken() {
        return "SC-" + UUID.randomUUID().toString().replace("-", "").substring(0, 10).toUpperCase();
    }

    public List<OrderSummary> findAllOrders() throws SQLException {
        List<OrderSummary> orders = new ArrayList<>();
        String sql = "SELECT id, token_number, student_name, total_amount, status, created_at FROM orders ORDER BY created_at DESC";
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet result = statement.executeQuery()) {
            while (result.next()) {
                Timestamp timestamp = result.getTimestamp("created_at");
                LocalDateTime createdAt = timestamp == null ? null : timestamp.toLocalDateTime();
                orders.add(new OrderSummary(result.getInt("id"), result.getString("token_number"),
                        result.getString("student_name"), result.getBigDecimal("total_amount"),
                        result.getString("status"), createdAt));
            }
        }
        return orders;
    }

    /** Returns only the signed-in student's orders, newest first. */
    public List<OrderSummary> findOrdersForStudent(String studentUsername) throws SQLException {
        List<OrderSummary> orders = new ArrayList<>();
        String sql = "SELECT id, token_number, student_name, total_amount, status, created_at "
                + "FROM orders WHERE student_name = ? ORDER BY created_at DESC";
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, studentUsername);
            try (ResultSet result = statement.executeQuery()) {
                while (result.next()) {
                    Timestamp timestamp = result.getTimestamp("created_at");
                    LocalDateTime createdAt = timestamp == null ? null : timestamp.toLocalDateTime();
                    String status = result.getString("status");
                    if ("COMPLETED".equals(status)) status = "READY";
                    orders.add(new OrderSummary(result.getInt("id"), result.getString("token_number"),
                            result.getString("student_name"), result.getBigDecimal("total_amount"), status, createdAt));
                }
            }
        }
        return orders;
    }

    public OrderSummary findOrderByToken(String token) throws SQLException {
        if (token == null || token.isBlank()) return null;
        String sql = "SELECT id, token_number, student_name, total_amount, status, created_at FROM orders WHERE token_number = ?";
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, token.trim());
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) return null;
                Timestamp timestamp = result.getTimestamp("created_at");
                LocalDateTime createdAt = timestamp == null ? null : timestamp.toLocalDateTime();
                String status = result.getString("status");
                if ("COMPLETED".equals(status)) status = "READY";
                return new OrderSummary(result.getInt("id"), result.getString("token_number"),
                        result.getString("student_name"), result.getBigDecimal("total_amount"), status, createdAt);
            }
        }
    }

    public OrderSummary findOrderByTokenForStudent(String token, String studentUsername) throws SQLException {
        if (token == null || token.isBlank() || studentUsername == null || studentUsername.isBlank()) return null;
        String sql = "SELECT id, token_number, student_name, total_amount, status, created_at FROM orders WHERE token_number = ? AND student_name = ?";
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, token.trim());
            statement.setString(2, studentUsername.trim());
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) return null;
                Timestamp timestamp = result.getTimestamp("created_at");
                LocalDateTime createdAt = timestamp == null ? null : timestamp.toLocalDateTime();
                String status = result.getString("status");
                if ("COMPLETED".equals(status)) status = "READY";
                return new OrderSummary(result.getInt("id"), result.getString("token_number"),
                        result.getString("student_name"), result.getBigDecimal("total_amount"), status, createdAt);
            }
        }
    }

    public List<FoodItem> findAllFoodItems() throws SQLException {
        List<FoodItem> items = new ArrayList<>();
        String sql = "SELECT id, name, description, category, price, available FROM food_items ORDER BY available DESC, category, name";
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet result = statement.executeQuery()) {
            while (result.next()) {
                items.add(new FoodItem(result.getInt("id"), result.getString("name"),
                        result.getString("description"), result.getString("category"), result.getBigDecimal("price"),
                        result.getBoolean("available")));
            }
        }
        return items;
    }

    public void saveFoodItem(Integer id, String name, String description, String category, BigDecimal price) throws SQLException {
        validateFoodItem(name, description, category, price);
        if (id == null) {
            String sql = "INSERT INTO food_items (name, description, category, price, available) VALUES (?, ?, ?, ?, TRUE)";
            try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
                bindFoodItem(statement, name, description, category, price);
                statement.executeUpdate();
            }
        } else {
            String sql = "UPDATE food_items SET name = ?, description = ?, category = ?, price = ? WHERE id = ?";
            try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(sql)) {
                bindFoodItem(statement, name, description, category, price);
                statement.setInt(5, id);
                if (statement.executeUpdate() != 1) throw new SQLException("Food item was not found.");
            }
        }
    }

    private void bindFoodItem(PreparedStatement statement, String name, String description, String category, BigDecimal price) throws SQLException {
        statement.setString(1, name.trim());
        statement.setString(2, description.trim());
        statement.setString(3, category.trim());
        statement.setBigDecimal(4, price);
    }

    private void validateFoodItem(String name, String description, String category, BigDecimal price) {
        if (name == null || name.trim().length() < 2 || name.trim().length() > 100) throw new IllegalArgumentException("Food name must be between 2 and 100 characters.");
        if (description == null || description.trim().length() < 3 || description.trim().length() > 255) throw new IllegalArgumentException("Description must be between 3 and 255 characters.");
        if (category == null || category.trim().length() < 2 || category.trim().length() > 50) throw new IllegalArgumentException("Category must be between 2 and 50 characters.");
        if (price == null || price.signum() <= 0 || price.scale() > 2) throw new IllegalArgumentException("Enter a valid positive price with up to two decimals.");
    }

    public void setFoodAvailability(int foodId, boolean available) throws SQLException {
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(
                "UPDATE food_items SET available = ? WHERE id = ?")) {
            statement.setBoolean(1, available);
            statement.setInt(2, foodId);
            if (statement.executeUpdate() != 1) throw new SQLException("Food item was not found.");
        }
    }

    public void updateOrderStatus(int orderId, String status) throws SQLException {
        List<String> validStatuses = List.of("PENDING", "PREPARING", "READY", "CANCELLED");
        if (!validStatuses.contains(status)) throw new IllegalArgumentException("Invalid order status.");
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(
                "UPDATE orders SET status = ? WHERE id = ?")) {
            statement.setString(1, status);
            statement.setInt(2, orderId);
            if (statement.executeUpdate() != 1) throw new SQLException("Order was not found.");
        }
    }

    public void deleteOrder(int orderId) throws SQLException {
        String status;
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(
                "SELECT status FROM orders WHERE id = ?")) {
            statement.setInt(1, orderId);
            try (ResultSet result = statement.executeQuery()) {
                if (!result.next()) throw new SQLException("Order was not found.");
                status = result.getString("status");
            }
        }
        if ("COMPLETED".equals(status)) status = "READY";
        if (!List.of("READY", "CANCELLED").contains(status)) {
            throw new IllegalArgumentException("Only READY or CANCELLED orders can be deleted.");
        }
        try (Connection connection = getConnection(); PreparedStatement statement = connection.prepareStatement(
                "DELETE FROM orders WHERE id = ?")) {
            statement.setInt(1, orderId);
            if (statement.executeUpdate() != 1) throw new SQLException("Order was not found.");
        }
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(url, username, password);
    }

    @Override
    public void close() { }
}
