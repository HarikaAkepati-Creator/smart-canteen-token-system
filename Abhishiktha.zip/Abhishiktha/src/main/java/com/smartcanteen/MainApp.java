package com.smartcanteen;

import com.smartcanteen.db.DatabaseService;
import com.smartcanteen.model.CartItem;
import com.smartcanteen.model.FoodItem;
import com.smartcanteen.model.OrderSummary;
import com.smartcanteen.model.UserAccount;
import javafx.application.Application;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.animation.FadeTransition;
import javafx.animation.KeyFrame;
import javafx.animation.ScaleTransition;
import javafx.animation.Timeline;
import javafx.scene.Node;
import javafx.util.Duration;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

public class MainApp extends Application {
    private final NumberFormat currency = NumberFormat.getCurrencyInstance(new Locale("en", "IN"));
    private DatabaseService database;
    private BorderPane root;
    private Label connectionBanner;
    private StudentView studentView;
    private AdminView adminView;
    private UserAccount currentUser;
    private Label sessionLabel;
    private Button logoutButton;

    @Override
    public void start(Stage stage) {
        database = new DatabaseService();
        String databaseError = null;
        try {
            database.initialize();
        } catch (Exception exception) {
            databaseError = friendlyDatabaseMessage(exception);
        }

        root = new BorderPane();
        root.getStyleClass().add("app-root");
        root.setTop(buildHeader());

        final String startupError = databaseError;
        showLoginScreen();

        if (startupError != null) {
            connectionBanner.setText("Database unavailable: " + startupError + "  |  Check README.md for setup.");
            connectionBanner.setVisible(true);
            connectionBanner.setManaged(true);
        }

        Scene scene = new Scene(root, 1180, 760);
        scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
        stage.setTitle("Smart Canteen Token System");
        stage.setMinWidth(980);
        stage.setMinHeight(650);
        stage.setScene(scene);
        stage.show();
    }

    private VBox buildHeader() {
        Label title = new Label("SMART CANTEEN");
        title.getStyleClass().add("brand-title");
        Label subtitle = new Label("Fast ordering • Clear tokens • Happier breaks");
        subtitle.getStyleClass().add("brand-subtitle");
        VBox branding = new VBox(3, title, subtitle);

        sessionLabel = new Label("Not signed in");
        sessionLabel.getStyleClass().add("session-label");
        logoutButton = new Button("Log out");
        logoutButton.getStyleClass().add("header-button");
        logoutButton.setVisible(false);
        logoutButton.setManaged(false);
        logoutButton.setOnAction(event -> logout());
        HBox sessionBar = new HBox(10, new Region(), sessionLabel, logoutButton);
        HBox.setHgrow(sessionBar.getChildren().get(0), Priority.ALWAYS);
        sessionBar.setAlignment(Pos.CENTER_RIGHT);

        connectionBanner = new Label();
        connectionBanner.getStyleClass().add("connection-banner");
        connectionBanner.setVisible(false);
        connectionBanner.setManaged(false);
        VBox header = new VBox(10, new HBox(branding, sessionBar), connectionBanner);
        header.getStyleClass().add("header");
        return header;
    }

    private VBox buildNavigation(UserAccount account) {
        VBox navigation;
        if (account.isAdmin()) {
            Button adminButton = new Button("▦  Admin dashboard");
            adminButton.getStyleClass().addAll("nav-button", "nav-button-active");
            adminButton.setMaxWidth(Double.MAX_VALUE);
            adminButton.setOnAction(event -> {
                root.setCenter(adminView);
                adminView.refresh();
            });
            navigation = new VBox(10, adminButton, new Region());
        } else {
            Button studentButton = new Button("🍽  Student ordering");
            studentButton.getStyleClass().addAll("nav-button", "nav-button-active");
            studentButton.setMaxWidth(Double.MAX_VALUE);
            studentButton.setOnAction(event -> root.setCenter(studentView));
            navigation = new VBox(10, studentButton, new Region());
        }
        VBox.setVgrow(navigation.getChildren().get(navigation.getChildren().size() - 1), Priority.ALWAYS);
        Label footer = new Label("Signed in as " + account.username() + "\nBuilt with JavaFX + JDBC");
        footer.getStyleClass().add("nav-footer");
        navigation.getChildren().add(footer);
        navigation.setPadding(new Insets(18, 12, 14, 12));
        navigation.setPrefWidth(230);
        navigation.getStyleClass().add("navigation");
        return navigation;
    }

    private void showLoginScreen() {
        currentUser = null;
        studentView = null;
        adminView = null;
        root.setLeft(null);
        root.setCenter(new LoginView(database, this::handleLogin, this::showError));
        sessionLabel.setText("Not signed in");
        logoutButton.setVisible(false);
        logoutButton.setManaged(false);
    }

    private void handleLogin(UserAccount account) {
        if (account == null || (!account.isStudent() && !account.isAdmin())) {
            showError("This account does not have a valid application role.");
            return;
        }
        currentUser = account;
        studentView = account.isStudent() ? new StudentView(database, account, this::showOrderSuccess, this::showError) : null;
        adminView = account.isAdmin() ? new AdminView(database, this::showError, account) : null;
        root.setLeft(buildNavigation(account));
        root.setCenter(account.isAdmin() ? adminView : studentView);
        sessionLabel.setText((account.isAdmin() ? "Admin" : "Student") + "  •  " + account.username());
        logoutButton.setVisible(true);
        logoutButton.setManaged(true);
        if (adminView != null) adminView.refresh();
    }

    private void logout() {
        if (studentView != null) studentView.stopTracking();
        if (adminView != null) adminView.stopRefreshing();
        showLoginScreen();
    }

    private class LoginView extends BorderPane {
        private final DatabaseService db;
        private final Consumer<UserAccount> onLogin;
        private final Consumer<String> onError;

        LoginView(DatabaseService db, Consumer<UserAccount> onLogin, Consumer<String> onError) {
            this.db = db;
            this.onLogin = onLogin;
            this.onError = onError;
            build();
        }

        private void build() {
            Label eyebrow = new Label("WELCOME TO SMART CANTEEN");
            eyebrow.getStyleClass().add("hero-badge");
            Label title = new Label("Order smarter. Collect happier.");
            title.getStyleClass().add("login-title");
            Label subtitle = new Label("Sign in to order food, track tokens, or manage the canteen menu.");
            subtitle.getStyleClass().add("page-hint");
            VBox intro = new VBox(6, eyebrow, title, subtitle);

            Tab studentLogin = new Tab("Student login", buildLoginForm("STUDENT", "Student username"));
            studentLogin.setClosable(false);
            Tab register = new Tab("Register", buildRegisterForm());
            register.setClosable(false);
            Tab adminLogin = new Tab("Admin login", buildLoginForm("ADMIN", "Admin username"));
            adminLogin.setClosable(false);
            TabPane tabs = new TabPane(studentLogin, register, adminLogin);
            tabs.getStyleClass().add("login-tabs");
            VBox card = new VBox(18, intro, tabs);
            card.getStyleClass().add("login-card");
            card.setMaxWidth(600);
            card.setPadding(new Insets(28));
            setCenter(card);
            setPadding(new Insets(36));
            setAlignment(card, Pos.CENTER);
        }

        private VBox buildLoginForm(String role, String usernamePrompt) {
            TextField username = new TextField();
            username.setPromptText(usernamePrompt);
            PasswordField password = new PasswordField();
            password.setPromptText("Password");
            Button login = new Button(role.equals("ADMIN") ? "Sign in as admin" : "Sign in as student");
            login.getStyleClass().add("primary-button");
            login.setMaxWidth(Double.MAX_VALUE);
            login.setOnAction(event -> authenticate(username.getText(), password.getText(), role));
            Label note = new Label(role.equals("ADMIN") ? "Default admin: admin / admin123" : "Use your registered student account.");
            note.getStyleClass().add("login-note");
            VBox form = new VBox(12, username, password, login, note);
            form.setPadding(new Insets(18, 4, 4, 4));
            return form;
        }

        private VBox buildRegisterForm() {
            TextField username = new TextField();
            username.setPromptText("Choose a student username");
            PasswordField password = new PasswordField();
            password.setPromptText("Password (at least 6 characters)");
            Button register = new Button("Create student account");
            register.getStyleClass().add("primary-button");
            register.setMaxWidth(Double.MAX_VALUE);
            register.setOnAction(event -> {
                try {
                    db.registerStudent(username.getText(), password.getText());
                    Alert success = new Alert(Alert.AlertType.INFORMATION);
                    success.setTitle("Registration complete");
                    success.setHeaderText("Student account created");
                    success.setContentText("You can now open Student login and sign in.");
                    success.showAndWait();
                    username.clear(); password.clear();
                } catch (IllegalArgumentException exception) {
                    onError.accept(exception.getMessage());
                } catch (Exception exception) {
                    onError.accept("Registration failed. Verify that MySQL is running.");
                }
            });
            Label note = new Label("Usernames use letters, numbers, dots, dashes, or underscores.");
            note.getStyleClass().add("login-note");
            return new VBox(12, username, password, register, note);
        }

        private void authenticate(String username, String password, String role) {
            try {
                onLogin.accept(db.authenticate(username, password, role));
            } catch (IllegalArgumentException exception) {
                onError.accept(exception.getMessage());
            } catch (Exception exception) {
                onError.accept("Login failed. Verify that MySQL is running and the account exists.");
            }
        }
    }

    private void showOrderSuccess(String token) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Order placed");
        alert.setHeaderText("Your order is confirmed!");
        alert.setContentText("Token number: " + token + "\nYour live status tracker is now active.");
        alert.showAndWait();
        studentView.trackOrder(token);
        // A student session has no admin dashboard. The saved order is already visible
        // to an administrator when they refresh their own signed-in dashboard.
        if (adminView != null) adminView.refresh();
    }

    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Smart Canteen");
        alert.setHeaderText("We could not complete that action");
        alert.setContentText(message);
        alert.showAndWait();
    }

    private String friendlyDatabaseMessage(Exception exception) {
        String message = exception.getMessage();
        if (message == null || message.isBlank()) return "Unable to connect to MySQL.";
        int detailStart = message.indexOf("Communications link failure");
        if (detailStart >= 0) return "MySQL is not running or the connection settings are incorrect.";
        return message.length() > 180 ? message.substring(0, 180) + "…" : message;
    }

    private String money(BigDecimal amount) { return currency.format(amount); }

    @Override
    public void stop() {
        if (studentView != null) studentView.stopTracking();
        if (adminView != null) adminView.stopRefreshing();
        if (database != null) database.close();
    }

    private class StudentView extends BorderPane {
        private final DatabaseService db;
        private final UserAccount account;
        private final Consumer<String> onOrderPlaced;
        private final Consumer<String> onError;
        private final ObservableList<CartItem> cart = FXCollections.observableArrayList();
        private final TableView<CartItem> cartTable = new TableView<>(cart);
        private final FlowPane foodGrid = new FlowPane();
        private final Label itemsMessage = new Label();
        private final Label totalLabel = new Label(money(BigDecimal.ZERO));
        private final Label cartCountLabel = new Label("0 items");
        private final TextField studentName = new TextField();
        private final TextField searchField = new TextField();
        private final ComboBox<String> categoryFilter = new ComboBox<>();
        private final VBox trackingPanel = new VBox(6);
        private final Label trackingToken = new Label();
        private final Label trackingStatus = new Label();
        private final HBox progressSteps = new HBox(6);
        private final VBox orderHistory = new VBox(6);
        private final Label cartFeedback = new Label();
        private Timeline trackingTimeline;
        private List<FoodItem> menuItems = List.of();

        StudentView(DatabaseService db, UserAccount account, Consumer<String> onOrderPlaced, Consumer<String> onError) {
            this.db = db;
            this.account = account;
            this.onOrderPlaced = onOrderPlaced;
            this.onError = onError;
            getStyleClass().add("content");
            build();
            loadFoodItems();
        }

        private void build() {
            Label heading = new Label("Order your meal");
            heading.getStyleClass().add("page-heading");
            Label hint = new Label("Fresh favourites, quick checkout, and a token you can track.");
            hint.getStyleClass().add("page-hint");
            Label heroBadge = new Label("●  OPEN NOW  •  PICK UP AT THE COUNTER");
            heroBadge.getStyleClass().add("hero-badge");
            VBox intro = new VBox(6, heroBadge, heading, hint);
            intro.setPadding(new Insets(0, 0, 12, 0));

            foodGrid.setHgap(14);
            foodGrid.setVgap(14);
            foodGrid.setPrefWrapLength(700);
            foodGrid.getStyleClass().add("food-grid");
            searchField.setPromptText("Search meals, snacks or drinks…");
            searchField.getStyleClass().add("search-field");
            searchField.textProperty().addListener((obs, oldValue, newValue) -> renderFoodItems());
            categoryFilter.setPromptText("All categories");
            categoryFilter.getStyleClass().add("filter-box");
            categoryFilter.valueProperty().addListener((obs, oldValue, newValue) -> renderFoodItems());
            HBox filters = new HBox(10, searchField, categoryFilter);
            HBox.setHgrow(searchField, Priority.ALWAYS);
            filters.getStyleClass().add("filters");
            ScrollPane foodScroll = new ScrollPane(foodGrid);
            foodScroll.setFitToWidth(true);
            foodScroll.setPrefHeight(455);
            foodScroll.getStyleClass().add("food-scroll");
            itemsMessage.getStyleClass().add("muted-text");
            HBox menuTitle = new HBox(10, new Label("TODAY'S MENU"), new Region(), new Label("Made fresh for your break"));
            HBox.setHgrow(menuTitle.getChildren().get(1), Priority.ALWAYS);
            ((Label) menuTitle.getChildren().get(0)).getStyleClass().add("section-label");
            ((Label) menuTitle.getChildren().get(2)).getStyleClass().add("menu-note");
            VBox menu = new VBox(12, menuTitle, filters, itemsMessage, foodScroll);
            VBox.setVgrow(foodScroll, Priority.ALWAYS);

            studentName.setText(account.username());
            studentName.setPromptText("Signed-in student");
            studentName.setDisable(true);
            studentName.setMaxWidth(Double.MAX_VALUE);
            Label customerLabel = new Label("Student details");
            customerLabel.getStyleClass().add("section-label");
            Label cartTitle = new Label("YOUR CART");
            cartTitle.getStyleClass().add("section-label");
            cartCountLabel.getStyleClass().add("cart-count");
            HBox cartHeading = new HBox(8, cartTitle, new Region(), cartCountLabel);
            HBox.setHgrow(cartHeading.getChildren().get(1), Priority.ALWAYS);
            Button placeOrder = new Button("Place order  →");
            placeOrder.getStyleClass().add("primary-button");
            placeOrder.setMaxWidth(Double.MAX_VALUE);
            placeOrder.setOnAction(event -> placeOrder());
            HBox totalRow = new HBox(10, new Label("Total"), new Region(), totalLabel);
            HBox.setHgrow(totalRow.getChildren().get(1), Priority.ALWAYS);
            totalRow.getStyleClass().add("total-row");
            Label checkoutNote = new Label("Your token will appear after secure checkout.");
            checkoutNote.getStyleClass().add("checkout-note");
            trackingPanel.getStyleClass().add("tracking-panel");
            trackingToken.getStyleClass().add("tracking-token");
            trackingStatus.getStyleClass().add("tracking-status");
            progressSteps.getStyleClass().add("progress-steps");
            trackingPanel.getChildren().addAll(new Label("LIVE ORDER TRACKER"), trackingToken, trackingStatus, progressSteps);
            trackingPanel.setVisible(false);
            trackingPanel.setManaged(false);
            cartFeedback.getStyleClass().add("cart-feedback");
            cartFeedback.setManaged(false);
            cartFeedback.setVisible(false);
            orderHistory.getStyleClass().add("order-history");
            VBox cartBox = new VBox(12, trackingPanel, orderHistory, customerLabel, studentName, cartHeading, cartFeedback, cartTable,
                    totalRow, checkoutNote, placeOrder);
            cartBox.getStyleClass().add("cart-panel");
            cartBox.setPadding(new Insets(20));
            cartBox.setPrefWidth(395);
            VBox.setVgrow(cartTable, Priority.ALWAYS);

            configureCartTable();
            setPadding(new Insets(24));
            setTop(intro);
            setCenter(menu);
            setRight(cartBox);
            BorderPane.setMargin(menu, new Insets(0, 16, 0, 0));
            refreshOrderHistory();
        }

        private void configureCartTable() {
            TableColumn<CartItem, String> itemColumn = new TableColumn<>("Item");
            itemColumn.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getName()));
            itemColumn.setPrefWidth(145);
            TableColumn<CartItem, Integer> quantityColumn = new TableColumn<>("Qty");
            quantityColumn.setCellValueFactory(data -> data.getValue().quantityProperty().asObject());
            quantityColumn.setCellFactory(column -> new TableCell<>() {
                private final Button minus = new Button("−");
                private final Button plus = new Button("+");
                private final Label value = new Label();
                private final HBox controls = new HBox(3, minus, value, plus);
                {
                    minus.getStyleClass().add("quantity-button");
                    plus.getStyleClass().add("quantity-button");
                    value.getStyleClass().add("quantity-value");
                    controls.setAlignment(Pos.CENTER);
                    minus.setOnAction(event -> changeQuantity(-1));
                    plus.setOnAction(event -> changeQuantity(1));
                }
                private void changeQuantity(int delta) {
                    if (getIndex() < 0 || getIndex() >= cart.size()) return;
                    CartItem item = cart.get(getIndex());
                    item.setQuantity(Math.max(1, Math.min(20, item.getQuantity() + delta)));
                    updateTotal();
                }
                @Override protected void updateItem(Integer quantity, boolean empty) {
                    super.updateItem(quantity, empty);
                    if (empty || quantity == null) setGraphic(null);
                    else { value.setText(String.valueOf(quantity)); setGraphic(controls); }
                }
            });
            quantityColumn.setPrefWidth(48);
            TableColumn<CartItem, BigDecimal> priceColumn = new TableColumn<>("Amount");
            priceColumn.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getLineTotal()));
            priceColumn.setCellFactory(column -> new TableCell<>() {
                @Override protected void updateItem(BigDecimal amount, boolean empty) {
                    super.updateItem(amount, empty);
                    setText(empty || amount == null ? null : money(amount));
                }
            });
            priceColumn.setPrefWidth(90);
            TableColumn<CartItem, Void> removeColumn = new TableColumn<>("");
            removeColumn.setCellFactory(column -> new TableCell<>() {
                private final Button remove = new Button("×");
                {
                    remove.getStyleClass().add("remove-button");
                    remove.setOnAction(event -> {
                        CartItem item = getTableView().getItems().get(getIndex());
                        cart.remove(item);
                        updateTotal();
                    });
                }
                @Override protected void updateItem(Void value, boolean empty) {
                    super.updateItem(value, empty);
                    setGraphic(empty ? null : remove);
                }
            });
            removeColumn.setPrefWidth(35);
            cartTable.getColumns().addAll(itemColumn, quantityColumn, priceColumn, removeColumn);
            cartTable.setPlaceholder(new Label("Your cart is empty"));
            cartTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
        }

        private void loadFoodItems() {
            foodGrid.getChildren().clear();
            try {
                menuItems = db == null ? List.of() : db.findAvailableFoodItems();
            } catch (Exception exception) {
                menuItems = db == null ? List.of() : db.demoFoodItems();
            }
            categoryFilter.getItems().clear();
            categoryFilter.getItems().add("All categories");
            menuItems.stream().map(FoodItem::getCategory).distinct().sorted().forEach(categoryFilter.getItems()::add);
            categoryFilter.setValue("All categories");
            renderFoodItems();
        }

        private void renderFoodItems() {
            foodGrid.getChildren().clear();
            String search = searchField.getText() == null ? "" : searchField.getText().trim().toLowerCase(Locale.ROOT);
            String category = categoryFilter.getValue();
            int shown = 0;
            for (FoodItem item : menuItems) {
                boolean matchesSearch = search.isBlank() || item.getName().toLowerCase(Locale.ROOT).contains(search)
                        || item.getDescription().toLowerCase(Locale.ROOT).contains(search)
                        || item.getCategory().toLowerCase(Locale.ROOT).contains(search);
                boolean matchesCategory = category == null || category.equals("All categories") || item.getCategory().equals(category);
                if (matchesSearch && matchesCategory) {
                    VBox card = createFoodCard(item);
                    foodGrid.getChildren().add(card);
                    animateCard(card, shown++);
                }
            }
            if (shown == 0) itemsMessage.setText("No dishes match your search. Try another category.");
            else if (db == null || !db.isAvailable()) itemsMessage.setText("Demo menu shown • connect MySQL to save orders");
            else itemsMessage.setText(shown + (shown == 1 ? " dish available" : " dishes available"));
        }

        private VBox createFoodCard(FoodItem item) {
            Label foodIcon = new Label(foodEmoji(item));
            foodIcon.getStyleClass().add("food-icon");
            StackPane iconWrap = new StackPane(foodIcon);
            iconWrap.getStyleClass().add("food-icon-wrap");
            Label category = new Label(item.getCategory().toUpperCase());
            category.getStyleClass().add("food-category");
            Label highlight = new Label(isChefPick(item) ? "★ CHEF'S PICK" : "FRESH TODAY");
            highlight.getStyleClass().add(isChefPick(item) ? "chef-pick" : "fresh-tag");
            Label name = new Label(item.getName());
            name.getStyleClass().add("food-name");
            name.setWrapText(true);
            Label description = new Label(item.getDescription());
            description.getStyleClass().add("food-description");
            description.setWrapText(true);
            Label price = new Label(money(item.getPrice()));
            price.getStyleClass().add("food-price");
            Spinner<Integer> quantity = new Spinner<>(1, 20, 1);
            quantity.setPrefWidth(78);
            Button add = new Button("Add");
            add.getStyleClass().add("add-button");
            add.setOnAction(event -> {
                addToCart(item, quantity.getValue());
                showCartFeedback(item.getName() + " added to your cart");
                ScaleTransition pulse = new ScaleTransition(Duration.millis(180), add);
                pulse.setFromX(1.0); pulse.setToX(1.08); pulse.setAutoReverse(true); pulse.setCycleCount(2); pulse.play();
            });
            HBox actionRow = new HBox(8, price, new Region(), quantity, add);
            HBox.setHgrow(actionRow.getChildren().get(1), Priority.ALWAYS);
            HBox cardTags = new HBox(8, category, highlight);
            VBox card = new VBox(8, iconWrap, cardTags, name, description, actionRow);
            card.getStyleClass().add("food-card");
            card.setPrefWidth(315);
            return card;
        }

        private void animateCard(Node card, int index) {
            card.setOpacity(0);
            FadeTransition fade = new FadeTransition(Duration.millis(260), card);
            fade.setDelay(Duration.millis(index * 45L));
            fade.setFromValue(0); fade.setToValue(1); fade.play();
        }

        private String foodEmoji(FoodItem item) {
            return switch (item.getCategory()) {
                case "Meals" -> "🍱";
                case "South Indian" -> item.getName().toLowerCase(Locale.ROOT).contains("idli") ? "🥣" : "🥞";
                case "Snacks" -> "🌯";
                case "Beverages" -> "🍋";
                default -> "🍴";
            };
        }

        private boolean isChefPick(FoodItem item) {
            return item.getName().contains("Thali") || item.getName().contains("Dosa") || item.getName().contains("Fried Rice");
        }

        private void addToCart(FoodItem item, int quantity) {
            for (CartItem cartItem : cart) {
                if (cartItem.getFoodItem().getId() == item.getId()) {
                    cartItem.setQuantity(Math.min(20, cartItem.getQuantity() + quantity));
                    cartTable.refresh();
                    updateTotal();
                    return;
                }
            }
            cart.add(new CartItem(item, quantity));
            updateTotal();
        }

        private void showCartFeedback(String message) {
            cartFeedback.setText("✓  " + message);
            cartFeedback.setManaged(true);
            cartFeedback.setVisible(true);
            FadeTransition fade = new FadeTransition(Duration.seconds(2.2), cartFeedback);
            fade.setFromValue(1); fade.setToValue(0);
            fade.setOnFinished(event -> {
                cartFeedback.setOpacity(1);
                cartFeedback.setVisible(false);
                cartFeedback.setManaged(false);
            });
            fade.playFromStart();
        }

        private void updateTotal() {
            BigDecimal total = cart.stream().map(CartItem::getLineTotal).reduce(BigDecimal.ZERO, BigDecimal::add);
            totalLabel.setText(money(total));
            int count = cart.stream().mapToInt(CartItem::getQuantity).sum();
            cartCountLabel.setText(count + (count == 1 ? " item" : " items"));
            cartTable.refresh();
        }

        private void trackOrder(String token) {
            trackingPanel.setVisible(true);
            trackingPanel.setManaged(true);
            trackingToken.setText("Token  " + token);
            trackingStatus.setText("●  PENDING  •  Checking for updates…");
            trackingStatus.getStyleClass().removeIf(style -> style.startsWith("tracking-"));
            trackingStatus.getStyleClass().add("tracking-pending");
            updateProgressSteps("PENDING");
            stopTracking();
            trackingTimeline = new Timeline(new KeyFrame(Duration.seconds(4), event -> refreshTrackedOrder(token)));
            trackingTimeline.setCycleCount(Timeline.INDEFINITE);
            trackingTimeline.play();
            refreshTrackedOrder(token);
        }

        private void refreshTrackedOrder(String token) {
            try {
                OrderSummary order = db.findOrderByTokenForStudent(token, account.username());
                if (order == null) return;
                String status = order.getStatus();
                trackingStatus.setText("●  " + status + "  •  Auto-updated just now");
                trackingStatus.getStyleClass().removeIf(style -> style.startsWith("tracking-"));
                trackingStatus.getStyleClass().add("tracking-" + status.toLowerCase(Locale.ROOT));
                updateProgressSteps(status);
                refreshOrderHistory();
                if ("READY".equals(status) || "CANCELLED".equals(status)) stopTracking();
            } catch (Exception ignored) {
                trackingStatus.setText("●  Tracking temporarily unavailable • retrying…");
            }
        }

        private void stopTracking() {
            if (trackingTimeline != null) {
                trackingTimeline.stop();
                trackingTimeline = null;
            }
        }

        private void updateProgressSteps(String status) {
            progressSteps.getChildren().clear();
            List<String> steps = List.of("PENDING", "PREPARING", "READY");
            int active = steps.indexOf(status);
            for (int i = 0; i < steps.size(); i++) {
                Label step = new Label((i <= active ? "● " : "○ ") + steps.get(i));
                step.getStyleClass().addAll("progress-step", i <= active ? "progress-active" : "progress-waiting");
                progressSteps.getChildren().add(step);
            }
            if ("CANCELLED".equals(status)) {
                progressSteps.getChildren().clear();
                Label cancelled = new Label("●  ORDER CANCELLED");
                cancelled.getStyleClass().addAll("progress-step", "progress-cancelled");
                progressSteps.getChildren().add(cancelled);
            }
        }

        private void refreshOrderHistory() {
            orderHistory.getChildren().clear();
            try {
                List<OrderSummary> orders = db.findOrdersForStudent(account.username());
                if (orders.isEmpty()) return;
                Label heading = new Label("RECENT ORDERS");
                heading.getStyleClass().add("section-label");
                orderHistory.getChildren().add(heading);
                orders.stream().limit(3).forEach(order -> {
                    Label line = new Label(order.getTokenNumber() + "  •  " + order.getStatus());
                    line.getStyleClass().add("history-line");
                    orderHistory.getChildren().add(line);
                });
            } catch (Exception ignored) {
                // The ordering screen remains usable if history cannot be refreshed.
            }
        }

        private void placeOrder() {
            try {
                if (db == null) throw new IllegalStateException("The database is not connected. Start MySQL and restart the application.");
                String token = db.placeOrder(account.username(), cart);
                cart.clear();
                updateTotal();
                refreshOrderHistory();
                onOrderPlaced.accept(token);
            } catch (IllegalArgumentException | IllegalStateException exception) {
                onError.accept(exception.getMessage());
            } catch (SQLException exception) {
                onError.accept("The order could not be saved: " + db.friendlyDatabaseError(exception));
            } catch (Exception exception) {
                onError.accept("The order could not be saved. Please try again.");
            }
        }
    }

    private class AdminView extends BorderPane {
        private final DatabaseService db;
        private final UserAccount account;
        private final Consumer<String> onError;
        private final TableView<OrderSummary> ordersTable = new TableView<>();
        private final ComboBox<String> statusBox = new ComboBox<>(FXCollections.observableArrayList(
                "PENDING", "PREPARING", "READY", "CANCELLED"));
        private final Label summary = new Label();
        private final Label totalMetric = new Label("0");
        private final Label pendingMetric = new Label("0");
        private final Label preparingMetric = new Label("0");
        private final Label readyMetric = new Label("0");
        private final Button deleteOrderButton = new Button("Delete finished order");
        private final TableView<FoodItem> menuTable = new TableView<>();
        private final TextField menuName = new TextField();
        private final TextField menuDescription = new TextField();
        private final TextField menuCategory = new TextField();
        private final TextField menuPrice = new TextField();
        private final Label menuSummary = new Label();
        private FoodItem selectedMenuItem;
        private Timeline refreshTimeline;

        AdminView(DatabaseService db, Consumer<String> onError, UserAccount account) {
            this.db = db;
            this.onError = onError;
            this.account = account;
            if (!account.isAdmin()) throw new IllegalArgumentException("Only admin accounts can open the admin dashboard.");
            getStyleClass().add("content");
            build();
        }

        private void build() {
            Label heading = new Label("Admin dashboard");
            heading.getStyleClass().add("page-heading");
            Label hint = new Label("Monitor incoming orders and keep students informed with live status updates.");
            hint.getStyleClass().add("page-hint");
            VBox intro = new VBox(5, heading, hint);
            intro.setPadding(new Insets(0, 0, 12, 0));

            HBox metrics = new HBox(12,
                    metricCard("TODAY'S ORDERS", totalMetric, "metric-total"),
                    metricCard("PENDING", pendingMetric, "metric-pending"),
                    metricCard("PREPARING", preparingMetric, "metric-preparing"),
                    metricCard("READY", readyMetric, "metric-ready"));

            configureOrdersTable();
            summary.getStyleClass().add("muted-text");
            Button refresh = new Button("↻  Refresh orders");
            refresh.getStyleClass().add("secondary-button");
            refresh.setOnAction(event -> refresh());
            HBox tableHeading = new HBox(12, new Label("ALL ORDERS"), new Region(), summary, refresh);
            HBox.setHgrow(tableHeading.getChildren().get(1), Priority.ALWAYS);
            ((Label) tableHeading.getChildren().get(0)).getStyleClass().add("section-label");

            statusBox.setPromptText("Select status");
            Button update = new Button("Update selected order");
            update.getStyleClass().add("primary-button");
            update.setOnAction(event -> updateSelectedOrder());
            deleteOrderButton.getStyleClass().add("danger-button");
            deleteOrderButton.setDisable(true);
            deleteOrderButton.setOnAction(event -> deleteSelectedOrder());
            Label helper = new Label("Select an order, choose its new status, then update.");
            helper.getStyleClass().add("muted-text");
            HBox actions = new HBox(10, new Label("Status:"), statusBox, update, deleteOrderButton, helper);
            actions.setAlignment(Pos.CENTER_LEFT);
            actions.getStyleClass().add("admin-actions");

            VBox page = new VBox(12, intro, metrics, tableHeading, ordersTable, actions);
            VBox.setVgrow(ordersTable, Priority.ALWAYS);
            Tab ordersTab = new Tab("Orders", page);
            ordersTab.setClosable(false);
            Tab menuTab = new Tab("Menu management", buildMenuPage());
            menuTab.setClosable(false);
            TabPane tabs = new TabPane(ordersTab, menuTab);
            tabs.getStyleClass().add("admin-tabs");
            setPadding(new Insets(24));
            setCenter(tabs);
            refreshTimeline = new Timeline(new KeyFrame(Duration.seconds(6), event -> refresh()));
            refreshTimeline.setCycleCount(Timeline.INDEFINITE);
            refreshTimeline.play();
        }

        private VBox metricCard(String title, Label value, String style) {
            Label label = new Label(title);
            label.getStyleClass().add("metric-label");
            value.getStyleClass().add("metric-value");
            VBox card = new VBox(4, label, value);
            card.getStyleClass().addAll("metric-card", style);
            HBox.setHgrow(card, Priority.ALWAYS);
            return card;
        }

        private VBox buildMenuPage() {
            configureMenuTable();
            menuName.setPromptText("Food name");
            menuDescription.setPromptText("Description");
            menuCategory.setPromptText("Category");
            menuPrice.setPromptText("Price");
            menuName.getStyleClass().add("admin-field");
            menuDescription.getStyleClass().add("admin-field");
            menuCategory.getStyleClass().add("admin-field");
            menuPrice.getStyleClass().add("admin-field");
            GridPane form = new GridPane();
            form.setHgap(10); form.setVgap(10);
            form.add(menuName, 0, 0); form.add(menuDescription, 1, 0);
            form.add(menuCategory, 0, 1); form.add(menuPrice, 1, 1);
            GridPane.setHgrow(menuName, Priority.ALWAYS); GridPane.setHgrow(menuDescription, Priority.ALWAYS);
            GridPane.setHgrow(menuCategory, Priority.ALWAYS); GridPane.setHgrow(menuPrice, Priority.ALWAYS);
            Button add = new Button("＋ Add item");
            Button update = new Button("✎ Update selected");
            Button toggle = new Button("◉ Change availability");
            Button clear = new Button("Clear form");
            add.getStyleClass().add("primary-button");
            update.getStyleClass().add("secondary-button");
            toggle.getStyleClass().add("secondary-button");
            clear.getStyleClass().add("subtle-button");
            add.setOnAction(event -> saveMenuItem(null));
            update.setOnAction(event -> {
                if (selectedMenuItem == null) onError.accept("Select a menu item before updating.");
                else saveMenuItem(selectedMenuItem.getId());
            });
            toggle.setOnAction(event -> toggleSelectedMenuItem());
            clear.setOnAction(event -> clearMenuForm());
            HBox actions = new HBox(10, add, update, toggle, clear, menuSummary);
            actions.setAlignment(Pos.CENTER_LEFT);
            actions.getStyleClass().add("admin-actions");
            VBox page = new VBox(10, new Label("Add, edit, and manage availability"), form, menuTable, actions);
            ((Label) page.getChildren().get(0)).getStyleClass().add("page-hint");
            VBox.setVgrow(menuTable, Priority.ALWAYS);
            return page;
        }

        private void configureMenuTable() {
            TableColumn<FoodItem, String> name = new TableColumn<>("Food item");
            name.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getName()));
            TableColumn<FoodItem, String> category = new TableColumn<>("Category");
            category.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getCategory()));
            TableColumn<FoodItem, BigDecimal> price = new TableColumn<>("Price");
            price.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getPrice()));
            price.setCellFactory(column -> new TableCell<>() {
                @Override protected void updateItem(BigDecimal value, boolean empty) {
                    super.updateItem(value, empty);
                    setText(empty || value == null ? null : money(value));
                }
            });
            TableColumn<FoodItem, String> availability = new TableColumn<>("Availability");
            availability.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().isAvailable() ? "AVAILABLE" : "OUT OF STOCK"));
            availability.setCellFactory(column -> new TableCell<>() {
                @Override protected void updateItem(String value, boolean empty) {
                    super.updateItem(value, empty);
                    if (empty || value == null) setGraphic(null);
                    else {
                        Label pill = new Label(value);
                        pill.getStyleClass().addAll("status-pill", value.equals("AVAILABLE") ? "status-ready" : "status-cancelled");
                        setGraphic(pill); setText(null);
                    }
                }
            });
            menuTable.getColumns().addAll(name, category, price, availability);
            menuTable.setPlaceholder(new Label("No menu items found"));
            menuTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
            menuTable.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
                selectedMenuItem = newValue;
                if (newValue != null) {
                    menuName.setText(newValue.getName());
                    menuDescription.setText(newValue.getDescription());
                    menuCategory.setText(newValue.getCategory());
                    menuPrice.setText(newValue.getPrice().toPlainString());
                }
            });
        }

        private void configureOrdersTable() {
            TableColumn<OrderSummary, String> token = new TableColumn<>("Token");
            token.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getTokenNumber()));
            token.setPrefWidth(170);
            TableColumn<OrderSummary, String> student = new TableColumn<>("Student");
            student.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getStudentName()));
            student.setPrefWidth(180);
            TableColumn<OrderSummary, BigDecimal> total = new TableColumn<>("Total");
            total.setCellValueFactory(data -> new SimpleObjectProperty<>(data.getValue().getTotalAmount()));
            total.setCellFactory(column -> new TableCell<>() {
                @Override protected void updateItem(BigDecimal amount, boolean empty) {
                    super.updateItem(amount, empty);
                    setText(empty || amount == null ? null : money(amount));
                }
            });
            total.setPrefWidth(110);
            TableColumn<OrderSummary, String> status = new TableColumn<>("Status");
            status.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getStatus()));
            status.setCellFactory(column -> new TableCell<>() {
                @Override protected void updateItem(String value, boolean empty) {
                    super.updateItem(value, empty);
                    if (empty || value == null) {
                        setGraphic(null);
                    } else {
                        Label pill = new Label(value);
                        pill.getStyleClass().addAll("status-pill", "status-" + value.toLowerCase(Locale.ROOT));
                        setGraphic(pill);
                        setText(null);
                    }
                }
            });
            status.setPrefWidth(130);
            TableColumn<OrderSummary, String> created = new TableColumn<>("Placed at");
            created.setCellValueFactory(data -> new SimpleStringProperty(
                    data.getValue().getCreatedAt() == null ? "—" : data.getValue().getCreatedAt().format(DateTimeFormatter.ofPattern("dd MMM, HH:mm"))));
            created.setPrefWidth(145);
            ordersTable.getColumns().addAll(token, student, total, status, created);
            ordersTable.setPlaceholder(new Label("No orders yet"));
            ordersTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY_FLEX_LAST_COLUMN);
            ordersTable.getSelectionModel().selectedItemProperty().addListener((obs, oldValue, newValue) -> {
                if (newValue != null) statusBox.setValue(newValue.getStatus());
                deleteOrderButton.setDisable(newValue == null || !("READY".equals(newValue.getStatus()) || "CANCELLED".equals(newValue.getStatus())));
            });
        }

        private void updateSelectedOrder() {
            OrderSummary selected = ordersTable.getSelectionModel().getSelectedItem();
            if (selected == null || statusBox.getValue() == null) {
                onError.accept("Select an order and a status before updating.");
                return;
            }
            try {
                db.updateOrderStatus(selected.getId(), statusBox.getValue());
                refresh();
            } catch (SQLException exception) {
                onError.accept("The order status could not be updated: " + db.friendlyDatabaseError(exception));
            } catch (Exception exception) {
                onError.accept("The order status could not be updated: " + exception.getMessage());
            }
        }

        private void deleteSelectedOrder() {
            OrderSummary selected = ordersTable.getSelectionModel().getSelectedItem();
            if (selected == null) {
                onError.accept("Select a READY or CANCELLED order before deleting.");
                return;
            }
            if (!("READY".equals(selected.getStatus()) || "CANCELLED".equals(selected.getStatus()))) {
                onError.accept("Only READY or CANCELLED orders can be deleted.");
                return;
            }
            try {
                db.deleteOrder(selected.getId());
                refresh();
            } catch (IllegalArgumentException exception) {
                onError.accept(exception.getMessage());
            } catch (SQLException exception) {
                onError.accept("The order could not be deleted: " + db.friendlyDatabaseError(exception));
            } catch (Exception exception) {
                onError.accept("The order could not be deleted: " + exception.getMessage());
            }
        }

        private void saveMenuItem(Integer itemId) {
            try {
                if (db == null) throw new IllegalStateException("The database is not connected.");
                BigDecimal price = new BigDecimal(menuPrice.getText().trim());
                db.saveFoodItem(itemId, menuName.getText(), menuDescription.getText(), menuCategory.getText(), price);
                menuSummary.setText(itemId == null ? "Item added" : "Item updated");
                clearMenuForm();
                refreshMenu();
                if (studentView != null) studentView.loadFoodItems();
            } catch (NumberFormatException exception) {
                onError.accept("Enter a valid price, for example 75 or 75.50.");
            } catch (IllegalArgumentException | IllegalStateException exception) {
                onError.accept(exception.getMessage());
            } catch (SQLException exception) {
                onError.accept("The menu item could not be saved: " + db.friendlyDatabaseError(exception));
            } catch (Exception exception) {
                onError.accept("The menu item could not be saved: " + exception.getMessage());
            }
        }

        private void toggleSelectedMenuItem() {
            if (selectedMenuItem == null) {
                onError.accept("Select a menu item first.");
                return;
            }
            try {
                db.setFoodAvailability(selectedMenuItem.getId(), !selectedMenuItem.isAvailable());
                menuSummary.setText(selectedMenuItem.isAvailable() ? "Item disabled" : "Item enabled");
                refreshMenu();
                if (studentView != null) studentView.loadFoodItems();
            } catch (SQLException exception) {
                onError.accept("The item availability could not be changed: " + db.friendlyDatabaseError(exception));
            } catch (Exception exception) {
                onError.accept("The item availability could not be changed: " + exception.getMessage());
            }
        }

        private void clearMenuForm() {
            selectedMenuItem = null;
            menuTable.getSelectionModel().clearSelection();
            menuName.clear(); menuDescription.clear(); menuCategory.clear(); menuPrice.clear();
        }

        private void refresh() {
            if (db == null) {
                summary.setText("Database unavailable");
                return;
            }
            try {
                OrderSummary selected = ordersTable.getSelectionModel().getSelectedItem();
                Integer selectedId = selected == null ? null : selected.getId();
                List<OrderSummary> orders = db.findAllOrders();
                ordersTable.setItems(FXCollections.observableArrayList(orders));
                restoreOrderSelection(selectedId);
                summary.setText(orders.size() + (orders.size() == 1 ? " order" : " orders"));
                totalMetric.setText(String.valueOf(orders.size()));
                pendingMetric.setText(String.valueOf(orders.stream().filter(order -> "PENDING".equals(order.getStatus())).count()));
                preparingMetric.setText(String.valueOf(orders.stream().filter(order -> "PREPARING".equals(order.getStatus())).count()));
                readyMetric.setText(String.valueOf(orders.stream().filter(order -> "READY".equals(order.getStatus())).count()));
                refreshMenu();
            } catch (Exception exception) {
                summary.setText("Could not load orders");
            }
        }

        private void stopRefreshing() {
            if (refreshTimeline != null) {
                refreshTimeline.stop();
                refreshTimeline = null;
            }
        }

        private void refreshMenu() {
            try {
                Integer selectedId = selectedMenuItem == null ? null : selectedMenuItem.getId();
                List<FoodItem> items = db.findAllFoodItems();
                menuTable.setItems(FXCollections.observableArrayList(items));
                restoreMenuSelection(selectedId);
                menuSummary.setText(items.size() + " menu items");
            } catch (Exception exception) {
                menuSummary.setText("Menu management needs MySQL");
            }
        }

        private void restoreOrderSelection(Integer selectedId) {
            if (selectedId == null) return;
            for (OrderSummary order : ordersTable.getItems()) {
                if (order.getId() == selectedId) {
                    ordersTable.getSelectionModel().select(order);
                    return;
                }
            }
        }

        private void restoreMenuSelection(Integer selectedId) {
            if (selectedId == null) return;
            for (FoodItem item : menuTable.getItems()) {
                if (item.getId() == selectedId) {
                    menuTable.getSelectionModel().select(item);
                    return;
                }
            }
        }
    }

    public static void main(String[] args) { launch(args); }
}
