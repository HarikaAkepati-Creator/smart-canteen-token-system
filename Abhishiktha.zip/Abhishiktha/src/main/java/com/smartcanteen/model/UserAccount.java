package com.smartcanteen.model;

public record UserAccount(String username, String role) {
    public boolean isAdmin() { return "ADMIN".equals(role); }
    public boolean isStudent() { return "STUDENT".equals(role); }
}
