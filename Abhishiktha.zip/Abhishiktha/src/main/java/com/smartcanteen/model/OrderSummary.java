package com.smartcanteen.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class OrderSummary {
    private final int id;
    private final String tokenNumber;
    private final String studentName;
    private final BigDecimal totalAmount;
    private String status;
    private final LocalDateTime createdAt;

    public OrderSummary(int id, String tokenNumber, String studentName, BigDecimal totalAmount,
                        String status, LocalDateTime createdAt) {
        this.id = id;
        this.tokenNumber = tokenNumber;
        this.studentName = studentName;
        this.totalAmount = totalAmount;
        this.status = status;
        this.createdAt = createdAt;
    }

    public int getId() { return id; }
    public String getTokenNumber() { return tokenNumber; }
    public String getStudentName() { return studentName; }
    public BigDecimal getTotalAmount() { return totalAmount; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
