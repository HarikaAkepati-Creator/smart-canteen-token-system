package com.smartcanteen.model;

import java.math.BigDecimal;

public class FoodItem {
    private final int id;
    private final String name;
    private final String description;
    private final String category;
    private final BigDecimal price;
    private final boolean available;

    public FoodItem(int id, String name, String description, String category, BigDecimal price) {
        this(id, name, description, category, price, true);
    }

    public FoodItem(int id, String name, String description, String category, BigDecimal price, boolean available) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.category = category;
        this.price = price;
        this.available = available;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public String getCategory() { return category; }
    public BigDecimal getPrice() { return price; }
    public boolean isAvailable() { return available; }
}
