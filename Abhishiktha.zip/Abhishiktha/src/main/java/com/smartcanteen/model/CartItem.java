package com.smartcanteen.model;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

import java.math.BigDecimal;

public class CartItem {
    private final FoodItem foodItem;
    private final IntegerProperty quantity;

    public CartItem(FoodItem foodItem, int quantity) {
        this.foodItem = foodItem;
        this.quantity = new SimpleIntegerProperty(Math.max(1, quantity));
    }

    public FoodItem getFoodItem() { return foodItem; }
    public String getName() { return foodItem.getName(); }
    public BigDecimal getUnitPrice() { return foodItem.getPrice(); }
    public IntegerProperty quantityProperty() { return quantity; }
    public int getQuantity() { return quantity.get(); }
    public void setQuantity(int value) { quantity.set(Math.max(1, value)); }
    public BigDecimal getLineTotal() { return foodItem.getPrice().multiply(BigDecimal.valueOf(getQuantity())); }
}
