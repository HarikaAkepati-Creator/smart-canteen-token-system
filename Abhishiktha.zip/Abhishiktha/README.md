# Smart Canteen Token System

A beginner-friendly JavaFX desktop application for ordering canteen food, generating unique tokens, and managing order status. It uses Core Java, JDBC, MySQL, and Maven.

## Features

- Student ordering screen with 12 sample food items, quantity selection, cart, search, category filters, and automatic total calculation.
- Separate student registration/login and admin login with role-based access.
- Student accounts can track only their own orders.
- The seeded admin account is `admin` with password `admin123` for local development; change it before real deployment.
- Unique token number for every saved order.
- Live student order tracking with automatic status refresh.
- Admin dashboard for viewing orders and changing status: `PENDING`, `PREPARING`, `READY`, or `CANCELLED`.
- Admin menu management for adding, editing, and temporarily disabling out-of-stock items.
- MySQL tables and sample food items are created automatically when the application starts.
- JDBC transactions ensure an order and all of its order details are saved together.
- Input validation and friendly error messages.

## Requirements

- JDK 17 or newer
- Maven 3.9+
- MySQL Server 8+

## Database setup

1. Start MySQL Server.
2. Create the database, or let MySQL Connector/J create it automatically:

   ```sql
   CREATE DATABASE smart_canteen;
   ```

3. The default connection settings are:

   - URL: `jdbc:mysql://localhost:3306/smart_canteen?createDatabaseIfNotExist=true&serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true`
   - User: `root`
   - Password: `root`

   Tables (`users`, `food_items`, `orders`, and `order_details`) and twelve sample food items are created automatically. Existing `COMPLETED` orders are migrated to `READY`.

If your MySQL credentials are different, use environment variables before running:

```powershell
$env:SMART_CANTEEN_DB_USER="root"
$env:SMART_CANTEEN_DB_PASSWORD="your-password"
$env:SMART_CANTEEN_DB_URL="jdbc:mysql://localhost:3306/smart_canteen?createDatabaseIfNotExist=true&serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true"
```

You can also override them with Maven system properties:

```powershell
mvn clean javafx:run "-Ddb.user=root" "-Ddb.password=your-password"
```

## Run from IntelliJ IDEA

1. Open the project folder as a Maven project.
2. Wait for Maven dependencies to finish importing.
3. Make sure the project SDK is JDK 17 or newer.
4. Run the Maven goal `javafx:run`, or run `com.smartcanteen.MainApp` after Maven has imported the dependencies.

## Run from a terminal

```powershell
mvn clean javafx:run
```

## Login

- Student users select **Register**, create an account with a username and password, then use **Student login**.
- The seeded development admin account is:

  - Username: `admin`
  - Password: `admin123`

  Only an authenticated admin sees the order-management and menu-management screens. Student order tracking is restricted in the database query to the signed-in student's username.

If MySQL is initially unavailable or the food table is empty, the application still opens with a colourful built-in demo menu so the interface can be explored. Start MySQL and restart the application to save orders; the database tables and sample rows will then be created automatically.
